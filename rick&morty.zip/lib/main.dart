import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rick_and_morty/presentation/pages/pages.dart';

import 'injection_container.dart' as sl;
import 'presentation/bloc/SimpleBlocObserver.dart';

void main() async {
  Bloc.observer = SimpleBlocObserver();
  await sl.init();

  runApp(
    App(
      key: UniqueKey(),
    ),
  );
}

class App extends StatelessWidget {
  App({required Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rick & Morty',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.blue.shade800,
        accentColor: Colors.blue.shade600,
      ),
      home: CharactersPage(),
    );
  }
}
