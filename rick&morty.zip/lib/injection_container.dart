
import 'package:dio/dio.dart';
import 'package:get_it/get_it.dart';
import 'package:rick_and_morty/data/data/source/character_api_client.dart';
import 'package:rick_and_morty/data/repositories/character_repository_impl.dart';
import 'package:rick_and_morty/domain/usecases/get_location.dart';
import 'package:rick_and_morty/domain/usecases/get_characters.dart';
import 'package:rick_and_morty/presentation/pages/details/bloc/bloc_location.dart';
import 'package:rick_and_morty/presentation/pages/list/bloc/list_bloc.dart';

import 'domain/repositories/character_repository.dart';

final serviceLocator = GetIt.instance;

Future<void> init() async {

  // network
  serviceLocator.registerLazySingleton<Dio>(() => Dio());
  serviceLocator.registerLazySingleton<CharacterApiClient>(() => CharacterApiClientImpl(httpClient: serviceLocator()));

  // repository
  serviceLocator.registerLazySingleton<CharacterRepository>(() => CharacterRepositoryImpl(client: serviceLocator()));

  // Use case
  serviceLocator.registerFactory(() => GetCharactersUseCase(repository: serviceLocator()));
  serviceLocator.registerFactory(() => GetLocationUseCase(repository: serviceLocator()));

  // Bloc
  serviceLocator.registerFactory(() => CharactersBloc(getCharactersUseCase: serviceLocator()));
  serviceLocator.registerFactory(() => LocationBloc(getLocationUseCase: serviceLocator()));

}