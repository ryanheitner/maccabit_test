import 'package:dio/dio.dart';

import '../../models/models.dart';

abstract class CharacterApiClient {
  Future<List<CharacterModel>> getCharacters(List<int> characterIds);

  Future<LocationModel> getLocation(int locationId);
}

class CharacterApiClientImpl implements CharacterApiClient {
  static const baseUrl = 'https://rickandmortyapi.com/api';
  final Dio httpClient;

  CharacterApiClientImpl({
    required this.httpClient,
  });

  @override
  Future<List<CharacterModel>> getCharacters(List<int> characterIds) async {
    String ids = "";
    characterIds.forEach((element) {
      ids += element.toString() + ",";
    });
    ids = ids.substring(0, ids.length - 1);

    final url = '$baseUrl/character/$ids';
    Response response = await this.httpClient.get(url);

    if (response.statusCode != 200) {
      throw Exception('error getting weather for location');
    }

    return (response.data as List)
        .map((character) => CharacterModel.fromJson(character))
        .toList();
  }

  @override
  Future<LocationModel> getLocation(int locationId) async {
    final url = '$baseUrl/location/$locationId';
    Response response = await this.httpClient.get(url);
    // print("YaminEl:API:getLocation:response" + response.toString());
    if (response.statusCode != 200) {
      throw Exception('error getting weather for location');
    }
    return LocationModel.fromJson(response.data);
  }
}
