import 'package:equatable/equatable.dart';

class CharacterModel extends Equatable {
  
  final int id;
  final String name;
  final String image;
  final String status;
  final String originLocationUrl;
  final String locationUrl;

  CharacterModel({required this.id, required this.name, required this.image, required this.status, required this.originLocationUrl, required this.locationUrl});

  factory CharacterModel.fromJson(Map<String, dynamic> json) {
    final origin = json['origin'];
    final location = json['location'];
    return CharacterModel(
     id: (json['id'] as num).toInt(),
     name: json['name'],
     image: json['image'],
     status: json['status'],
     originLocationUrl: origin['url'],
     locationUrl: location['url'],
    );
  }

  @override
  List<Object> get props => [id, name, image, status, originLocationUrl, locationUrl];
}
