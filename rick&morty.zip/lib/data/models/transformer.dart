import '../../domain/entities/entities.dart';
import '../models/models.dart';

class Transformers {
  static CharacterEntity modelToEntity(CharacterModel model) {
    return CharacterEntity(
        id: model.id,
        name: model.name,
        image: model.image,
        status: model.status,
        originLocationId: _getIdFromUrl(model.originLocationUrl),
        locationId: _getIdFromUrl(model.locationUrl));
  }

  static int _getIdFromUrl(String url) {
    if (url.isEmpty) {
      return 0;
    }
    return int.parse(url.split("/").last);
  }

  static LocationEntity locationModelToEntity(LocationModel model) {
    return LocationEntity(
        id: model.id,
        name: model.name,
        type: model.type ?? "",
        dimension: model.dimension ?? "");
  }
}
