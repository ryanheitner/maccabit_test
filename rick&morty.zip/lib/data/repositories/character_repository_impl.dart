import 'package:rick_and_morty/data/data/source/character_api_client.dart';
import 'package:rick_and_morty/data/models/transformer.dart';
import 'package:rick_and_morty/domain/entities/character_entity.dart';
import 'package:rick_and_morty/domain/entities/location_entity.dart';
import 'package:rick_and_morty/domain/repositories/character_repository.dart';

class CharacterRepositoryImpl implements CharacterRepository {
  final CharacterApiClient client;
  Map<int, LocationEntity> entities = Map();

  CharacterRepositoryImpl({required this.client}) {
    print("YaminEl:CharacterRepositoryImpl");
  }

  @override
  Future<List<CharacterEntity>> getCharacters(List<int> characterIds) async {
    final models = await client.getCharacters(characterIds);
    return models.map((model) => Transformers.modelToEntity(model)).toList();
  }

  @override
  Future<LocationEntity> getLocation(int locationId) async {
    print("YaminEl:getLocation:locationId: " + locationId.toString());
    if (entities.containsKey(locationId)) {
      return entities[locationId]!;
    } else {
      final model = await client.getLocation(locationId);
      print("YaminEl:getLocation:model" + model.toString());
      LocationEntity entity = Transformers.locationModelToEntity(model);
      entities[entity.id] = entity;
      return entity;
    }
  }
}
