import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:rick_and_morty/domain/entities/entities.dart';

@immutable
abstract class LocationState extends Equatable {
  const LocationState();

  @override
  List<Object> get props => [];
}

class Initial extends LocationState {}

class Loading extends LocationState {}

class LoadSuccess extends LocationState {
  final LocationEntity location;

  const LoadSuccess({required this.location});

  @override
  List<Object> get props => [location];
}

class LoadFailure extends LocationState {}
