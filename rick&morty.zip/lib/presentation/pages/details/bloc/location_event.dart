import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

@immutable
abstract class LocationEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class GetLocationDetails extends LocationEvent {
  final int locationId;

  GetLocationDetails({required this.locationId});

  @override
  List<Object> get props => [locationId];
}
