import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rick_and_morty/domain/entities/entities.dart';
import 'package:rick_and_morty/domain/usecases/get_location.dart';

import 'bloc_location.dart';

class LocationBloc extends Bloc<LocationEvent, LocationState> {
  final GetLocationUseCase getLocationUseCase;

  LocationBloc({required this.getLocationUseCase}) : super(Initial()) {
    print("YaminEl:LocationBloc INIT");
  }

  @override
  Stream<LocationState> mapEventToState(LocationEvent event) async* {
    print("YaminEl:mapEventToState" + event.toString());
    if (event is GetLocationDetails) {
      yield* _mapGetLocationToState(event);
    }
  }

  Stream<LocationState> _mapGetLocationToState(
      GetLocationDetails event) async* {
    yield Loading();
    try {
      final LocationEntity entity =
          await getLocationUseCase.getLocation(event.locationId);
      yield LoadSuccess(location: entity);
    } catch (e) {
      print("YaminEl:Character:LoadError" + e.toString());
      yield LoadFailure();
    }
  }
}
