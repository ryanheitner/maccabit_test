import 'package:flutter/material.dart';
import 'package:rick_and_morty/domain/entities/entities.dart';
import 'package:rick_and_morty/presentation/pages/details/widget/character_details.dart';

class DetailsPage extends StatelessWidget {
  final CharacterEntity entity;

  const DetailsPage({Key? key, required this.entity}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Shelfy Test - Details'),
      ),
      body: CharacterDetails(
        entity: entity,
      ),
    );
  }
}
