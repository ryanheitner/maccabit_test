import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rick_and_morty/domain/entities/entities.dart';

import '../../../../injection_container.dart';
import '../bloc/bloc_location.dart';
import '../bloc/location_bloc.dart';
import '../widget/details_widgets.dart';

class LocationDetails extends StatelessWidget {
  final int locationId;
  final String title;

  const LocationDetails(
      {Key? key, required this.locationId, required this.title})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => serviceLocator<LocationBloc>()
        ..add(GetLocationDetails(locationId: locationId)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.detailsTitle),
          BlocBuilder<LocationBloc, LocationState>(
            builder: (context, state) {
              if (state is Loading || state is Initial) {
                return SizedBox(
                    height: 30,
                    width: 30,
                    child: CircularProgressIndicator());
              } else if (state is LoadSuccess) {
                return _buildLocation(state.location, context);
              } else if (state is LoadFailure) {
                return Text("ERROR");
              } else {
                return Text("Else");
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildLocation(LocationEntity location, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("location: ${location.name}", style: Theme.of(context).textTheme.detailsSubtitle,),
          if (location.type.isNotEmpty) Text("type: ${location.type}", style: Theme.of(context).textTheme.detailsSubtitle,),
          if (location.dimension.isNotEmpty) Text("dimension: ${location.dimension}", style: Theme.of(context).textTheme.detailsSubtitle,),
        ],
      ),
    );
  }
}
