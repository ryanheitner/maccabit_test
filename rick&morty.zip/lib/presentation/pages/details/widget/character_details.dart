import 'package:flutter/material.dart';
import 'package:rick_and_morty/domain/entities/entities.dart';
import 'package:rick_and_morty/presentation/pages/details/widget/details_widgets.dart';

class CharacterDetails extends StatelessWidget {
  final CharacterEntity entity;

  const CharacterDetails({Key? key, required this.entity}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Padding(
                padding: const EdgeInsets.only(bottom: 16.0, top: 8.0),
                child: Text(
                  "${entity.name}",
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  style: TextStyle(
                      color: Colors.blue,
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Center(child: Hero(tag: "Image_${entity.id}", child: Image.network(entity.image))),
            Padding(
              padding: const EdgeInsets.only(top: 16.0, bottom: 8.0),
              child: Text(
                "Status: ${entity.status}",
                textAlign: TextAlign.start,
                style: Theme.of(context).textTheme.detailsTitle,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0, bottom: 8.0),
              child: LocationDetails(title: "Origin",locationId: entity.originLocationId,),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0, bottom: 8.0),
              child: LocationDetails(title: "Location",locationId: entity.locationId,),
            ),
          ],
        ),
      ),
    );
  }
}
