export 'list/characters_page.dart';
export 'details/widget/details_page.dart';