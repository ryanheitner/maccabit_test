import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rick_and_morty/domain/entities/entities.dart';
import 'package:rick_and_morty/domain/usecases/get_characters.dart';

import 'list_bloc.dart';

class CharactersBloc extends Bloc<CharactersEvent, CharactersState> {
  final GetCharactersUseCase getCharactersUseCase;

  CharactersBloc({required this.getCharactersUseCase}) : super(Initial()) {
    print("YaminEl:CharactersBloc");
  }

  @override
  Stream<CharactersState> mapEventToState(CharactersEvent event) async* {
    print("YaminEl:mapEventToState" + event.toString());
    if (event is GetCharacters) {
      yield* _mapGetCharactersToState(event);
    }
  }

  Stream<CharactersState> _mapGetCharactersToState(GetCharacters event) async* {
    yield Loading();
    try {
      final List<CharacterEntity> entities = await getCharactersUseCase.getCharacters();
      yield LoadSuccess(characters: entities);
    } catch (e) {
      print("YaminEl:LoadError: " + e.toString());
      yield LoadFailure();
    }
  }
}
