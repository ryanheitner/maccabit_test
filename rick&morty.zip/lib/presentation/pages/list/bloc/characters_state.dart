
import 'package:equatable/equatable.dart';
import 'package:flutter/widgets.dart';
import 'package:rick_and_morty/domain/entities/entities.dart';

@immutable
abstract class CharactersState extends Equatable {
  const CharactersState();

  @override
  List<Object> get props => [];
}

class Initial extends CharactersState {}

class Loading extends CharactersState {}

class LoadSuccess extends CharactersState {
  final List<CharacterEntity> characters;

  const LoadSuccess({required this.characters});

  @override
  List<Object> get props => [characters];
}

class LoadFailure extends CharactersState {}
