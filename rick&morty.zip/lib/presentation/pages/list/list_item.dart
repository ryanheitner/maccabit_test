import 'package:flutter/material.dart';
import 'package:rick_and_morty/domain/entities/entities.dart';
import 'package:rick_and_morty/presentation/pages/details/widget/details_page.dart';

class ListItem extends StatelessWidget {
  final CharacterEntity entity;

  const ListItem({Key? key, required this.entity}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(
        'Name: ${entity.name}',
      ),
      isThreeLine: true,
      subtitle: Text(
        'Status: ${entity.status}',
      ),
      trailing: Hero(
        tag: "Image_${entity.id}",
        child: Image.network(
          entity.image,
        ),
      ),
      dense: false,
      onTap: () {
        print("YaminEl:onTap" + entity.toString());

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => DetailsPage(entity: entity,),
          ),
        );
      },
    );
  }
}
