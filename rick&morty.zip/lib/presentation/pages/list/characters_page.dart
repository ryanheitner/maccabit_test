import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rick_and_morty/presentation/pages/list/bloc/list_bloc.dart';
import 'package:rick_and_morty/presentation/pages/list/list_item.dart';

import '../../../injection_container.dart';

class CharactersPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Shelfy Test - List'),
      ),
      body: BlocProvider(
        create: (_) => serviceLocator<CharactersBloc>()..add(GetCharacters()),
        child: buildPage(context),
      ),
    );
  }

  Widget buildPage(BuildContext context) {
    return BlocBuilder<CharactersBloc, CharactersState>(
      builder: (context, state) {
        if (state is Loading || state is Initial) {
          return Center(
              child: SizedBox(
                  height: 100, width: 100, child: CircularProgressIndicator(strokeWidth: 5,)));
        } else if (state is LoadSuccess) {
          return MyList();
        } else if (state is LoadFailure) {
          return Text("ERROR");
        } else {
          return Text("Else");
        }
      },
    );
  }
}

class MyList extends StatefulWidget {
  @override
  _MyListState createState() => _MyListState();
}

class _MyListState extends State<MyList> {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CharactersBloc, CharactersState>(
      buildWhen: (previous, current) => current is LoadSuccess,
      builder: (context, state) {
        return Container(
          color: Colors.grey,
          child: ListView.builder(
            itemCount: (state as LoadSuccess).characters.length,
            itemBuilder: (BuildContext context, int index) {
              return Card(child: ListItem(entity: state.characters[index]));
            },
          ),
        );
      },
    );
  }
}
