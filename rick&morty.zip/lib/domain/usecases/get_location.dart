
import 'package:rick_and_morty/domain/entities/entities.dart';
import 'package:rick_and_morty/domain/repositories/character_repository.dart';

class GetLocationUseCase {
  final CharacterRepository repository;

  GetLocationUseCase({required this.repository});

  Future<LocationEntity> getLocation(int id) async {
    return repository.getLocation(id);
  }
}