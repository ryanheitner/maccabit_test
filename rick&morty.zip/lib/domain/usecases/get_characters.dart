
import 'dart:collection';

import 'package:rick_and_morty/domain/entities/entities.dart';
import 'package:rick_and_morty/domain/repositories/character_repository.dart';
import 'dart:math';

class GetCharactersUseCase {
  final CharacterRepository repository;
  static final _rnd = Random();

  GetCharactersUseCase({required this.repository});

  Future<List<CharacterEntity>> getCharacters() async {
    final HashSet<int> ids = HashSet.identity();
    while (ids.length < 12) {
      ids.add(_rnd.nextInt(600) + 1);
    }
    return repository.getCharacters(ids.toList());
  }
}