
import 'package:rick_and_morty/domain/entities/character_entity.dart';
import 'package:rick_and_morty/domain/entities/entities.dart';

abstract class CharacterRepository {
  Future<List<CharacterEntity>> getCharacters(List<int> characterIds);
  Future<LocationEntity> getLocation(int locationId);
}